
# Later Years and Death

## Last Years in Persia

Upon his return to Persia, Alexander faced various challenges, including rebellions and administrative issues. He also began to implement policies aimed at integrating Persians into his empire, such as encouraging his soldiers to marry Persian women. This policy, known as the [[Susa weddings]], was met with resistance from some of his Macedonian officers.

## Death

Alexander died in Babylon in June 323 BC at the age of 32. The cause of his death is still debated by historians, with theories ranging from illness (malaria, typhoid fever, West Nile virus) to poisoning. His body was initially preserved in honey and transported to Memphis, Egypt, and later to Alexandria.

## Succession

Alexander's death led to a power struggle among his generals, known as the [[Diadochi]]. His empire was eventually divided among them, leading to the establishment of several Hellenistic kingdoms, including the [[Ptolemaic Kingdom]] in Egypt, the [[Seleucid Empire]] in Asia, and the [[Antigonid Kingdom]] in Macedon.


