# Early Life and Education

Alexander III was born in Pella, the capital of the Kingdom of Macedon, on 20 July 356 BC. He was the son of Philip II, the king of Macedon, and Olympias, daughter of Neoptolemus I, king of Epirus.

Several legends surround Alexander's birth and childhood. According to Plutarch, Olympias dreamed that her womb was struck by a thunderbolt before his birth, and Philip dreamed of sealing her womb with a lion's image. These legends may have been propagated to suggest Alexander's divine parentage and destiny for greatness.

In his early years, Alexander was raised by a nurse, Lanike, and later tutored by Leonidas and Lysimachus of Acarnania. He was educated in the manner of noble Macedonian youths, learning to read, play the lyre, ride, fight, and hunt.

At age ten, Alexander famously tamed Bucephalas, a wild horse that no one else could ride. Philip, impressed by his son's courage, declared, "My boy, you must find a kingdom big enough for your ambitions. Macedon is too small for you."

At age 13, Alexander began to be tutored by Aristotle, who Philip hired for the purpose. At Mieza, Alexander and other Macedonian nobles, including Ptolemy and Cassander, were taught medicine, philosophy, morals, religion, logic, and art. Aristotle instilled in Alexander a passion for Homer's works, particularly the Iliad, an annotated copy of which Alexander carried on his campaigns. Aristotle also taught Alexander to treat Greeks as friends and others as slaves, a view that influenced Alexander's later policies. Alexander's education with Aristotle concluded in 335 BC.





![Alexander and Aristotle](/home/ubuntu/Alexander_and_Aristotle.jpg)


