
# Historiography

Most of the primary sources about Alexander's life are lost. Our knowledge of him comes from secondary sources written centuries after his death, such as those by [[Arrian]], [[Plutarch]], [[Diodorus Siculus]], and [[Quintus Curtius Rufus]]. These sources often present conflicting accounts, and historians continue to debate the accuracy of various events in his life.


