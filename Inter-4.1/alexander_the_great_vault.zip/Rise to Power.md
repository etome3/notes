# Rise to Power

## Regency and Early Campaigns

At the age of 16, Alexander's education under Aristotle ended. Philip II went off to wage war against Byzantium, leaving Alexander in charge as regent and heir apparent to Macedon. During Philip's absence, the Maedi of northern Macedonia revolted. Alexander responded quickly, driving them from their territory, colonizing it with Greeks, and founding a city named Alexandropolis.

Upon Philip's return, he dispatched Alexander with a small force to suppress a revolt in southern Thrace. In 340 BC, Alexander commanded the Macedonian forces in the Battle of Chaeronea against the combined armies of Athens and Thebes. Philip's forces were victorious, and Alexander was said to be the first to break the Sacred Band of Thebes.

## Exile and Return

Philip's marriage to Cleopatra Eurydice of Macedon, niece of his general Attalus, endangered Alexander's position as heir to the throne. During the wedding banquet, Attalus publicly insulted Alexander's legitimacy, leading to a confrontation where Philip almost attacked Alexander. Alexander, his mother Olympias, and his sister Cleopatra fled to Epirus and then to Illyria.

Philip eventually reconciled with Alexander, who returned to Macedon six months later. In 336 BC, Philip was assassinated by his bodyguard Pausanias of Orestis. Alexander was immediately proclaimed king by the Macedonian army and nobles.

## Accession to the Throne

At 20 years old, Alexander quickly consolidated his power by eliminating rivals and securing the loyalty of the army. He suppressed rebellions in Thessaly and Thrace, then marched south to Greece to reassert Macedonian authority. He convened the League of Corinth and was appointed its leader, with the ultimate goal of invading Persia.


