
# Legacy

Alexander's legacy is immense and far-reaching. His conquests spread Greek culture and influence across a vast area, leading to the [[Hellenistic Age]]. He founded numerous cities, many of which were named Alexandria, that became centers of trade and culture. His military tactics and strategies were studied for centuries. He remains one of the most influential figures in history.


