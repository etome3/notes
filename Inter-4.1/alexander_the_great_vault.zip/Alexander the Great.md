# Alexander the Great

Alexander III of Macedon, commonly known as Alexander the Great, was a king of the ancient Greek kingdom of Macedon. He succeeded his father Philip II to the throne in 336 BC at the age of 20 and spent most of his ruling years conducting lengthy military campaigns throughout Western Asia, Central Asia, parts of South Asia, and Egypt. By the age of 30, he had created one of the largest empires in history, stretching from Greece to northwestern India. He was undefeated in battle and is widely considered to be one of history's greatest and most successful military commanders.

His legacy is immense and far-reaching, marking the start of the Hellenistic period. His conquests spread Greek culture and influence across a vast area, leading to the Hellenistic Age. He founded numerous cities, many of which were named Alexandria, that became centers of trade and culture. His military tactics and strategies were studied for centuries. He remains one of the most influential figures in history.

## Table of Contents

*   [[Early Life and Education]]
*   [[Rise to Power]]
*   [[Conquests]]
    *   [[Conquests/Balkan Campaign]]
    *   [[Conquests/Asia Minor]]
    *   [[Conquests/Levant and Egypt]]
    *   [[Conquests/Conquest of Persia]]
    *   [[Conquests/Indian Campaign]]
*   [[Later Years and Death]]
*   [[Character]]
*   [[Legacy]]
*   [[Historiography]]





![Alexander's Conquests Map](/home/ubuntu/Alexander_Conquests_Map.jpg)


