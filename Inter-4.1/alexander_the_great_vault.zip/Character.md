# Character

Alexander's character is complex and has been interpreted in various ways throughout history. He was known for his ambition, military genius, and charisma. He was also known for his ruthlessness, his temper, and his heavy drinking. He was a complex figure who inspired both admiration and fear.


