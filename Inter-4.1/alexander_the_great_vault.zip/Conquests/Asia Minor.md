# Asia Minor Campaign

In 334 BC, Alexander crossed the Hellespont into Asia Minor, beginning his invasion of the Achaemenid Persian Empire. His first major battle was the [[Battle of the Granicus River]], where he defeated a Persian army. He then proceeded to liberate the Greek cities of Asia Minor, including Sardis and Ephesus.


