# Balkan Campaign

Before invading Persia, Alexander embarked on a campaign in the Balkans to secure Macedon's northern borders. In 335 BC, he marched against the Triballi and Illyrians, defeating them in a series of battles. He then turned south to Thebes, which had revolted against Macedonian rule. Alexander besieged and captured the city, destroying it as a warning to other Greek city-states.


