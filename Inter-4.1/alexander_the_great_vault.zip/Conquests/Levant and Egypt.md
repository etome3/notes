# Levant and Egypt Campaign

After securing Asia Minor, Alexander marched south into the Levant. He besieged and captured the city of [[Tyre]] after a seven-month siege. He then continued into Egypt, where he was welcomed as a liberator. He founded the city of [[Alexandria]] in Egypt, which would become a major center of Hellenistic culture. In Egypt, he also visited the [[Oracle of Amun]] at [[Siwa Oasis]], where he was proclaimed a son of Zeus.


