
# Conquest of Persia

Alexander then turned his attention to the heart of the Persian Empire. In 331 BC, he confronted the main Persian army, led by [[Darius III]], at the [[Battle of Gaugamela]]. Alexander achieved a decisive victory, and Darius fled. Alexander then captured the Persian capitals of [[Babylon]], [[Susa]], and [[Persepolis]]. At Persepolis, he burned the royal palace, an act that is still debated by historians.


