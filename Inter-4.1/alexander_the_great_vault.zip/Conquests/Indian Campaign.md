# Indian Campaign

In 326 BC, Alexander began his invasion of India. He crossed the [[Indus River]] and marched into the [[Punjab]]. He faced strong resistance from local rulers, including [[Porus]], king of the [[Pauravas]].

## Battle of the Hydaspes

Alexander fought his most difficult battle in India against Porus at the [[Battle of the Hydaspes River]]. Despite the use of war elephants by Porus, Alexander's forces were victorious. Alexander was impressed by Porus's bravery and allowed him to continue ruling his kingdom as a satrap.

## Mutiny and Return

After the Battle of the Hydaspes, Alexander's troops, exhausted and homesick, refused to march further east. Alexander was forced to turn back. He sailed down the [[Indus River]] to the [[Indian Ocean]], and then marched his army through the [[Gedrosian Desert]], a harsh and difficult journey that resulted in heavy losses.


